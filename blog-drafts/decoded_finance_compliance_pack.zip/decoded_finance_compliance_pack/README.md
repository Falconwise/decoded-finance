# decoded.finance Compliance Pack (Phase 0.1)

This package contains:
- Legal pages (Markdown) under `src/content/legal/`
- Reusable disclaimer blocks under `src/components/Compliance/`
- A publish gate checklist
- A restricted phrases list for QA

## Action required
Replace `<LINKEDIN_URL>` in all legal pages with your actual LinkedIn profile URL.

## Suggested Astro wiring
- Footer disclaimer: load `src/components/Compliance/FooterDisclaimer.txt`
- Post disclaimers: include ShortDisclaimer or LongDisclaimer based on `riskLevel` frontmatter.

## Disclaimer
This package is a practical drafting framework and is not legal advice.
