---
title: "Cookies Policy"
description: "How cookies and similar technologies are used on decoded.finance."
pubDate: 2026-02-15
tags:
  - Legal
  - Cookies
---

## Summary

decoded.finance may use cookies and similar technologies to operate the site and measure usage.

## What are cookies

Cookies are small text files stored on your device that help websites function and collect analytics information.

## Types of cookies

### Essential cookies
Used to operate the site reliably. These may include security and performance related cookies.

### Analytics cookies
Used to understand how visitors interact with the site. decoded.finance uses Google Analytics.

## Consent

Cookie consent implementation depends on site configuration. The site may show a cookie banner that allows you to accept or reject analytics cookies.

If you reject analytics cookies, the site should still function, but usage measurement may be limited.

## How to control cookies

You can control cookies through your browser settings, including deleting cookies and blocking them. Note that blocking cookies may affect site functionality.

## Contact

Contact the author via LinkedIn:
<LINKEDIN_URL>
