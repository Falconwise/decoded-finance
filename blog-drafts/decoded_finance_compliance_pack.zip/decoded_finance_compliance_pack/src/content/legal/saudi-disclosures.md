---
title: "Saudi Capital Markets Disclosures"
description: "Jurisdictional disclosures for content related to Saudi markets, IPOs, and securities."
pubDate: 2026-02-15
tags:
  - Legal
  - Disclosures
  - Saudi Arabia
---

## Summary

decoded.finance publishes educational content about corporate finance, valuation frameworks, and capital markets. This page explains how such content should be read and what it is not.

## Not an offer or solicitation

Nothing on decoded.finance is intended to be, or should be interpreted as, an offer, solicitation, invitation, or inducement in relation to securities, IPO subscriptions, or other regulated transactions.

## Information only

Any discussion of Saudi securities, IPOs, valuations, or market data is provided for educational purposes only.

Readers should refer to official filings and disclosures and consult appropriately licensed professionals before making decisions.

## Audience and distribution

This site is not intended to target any specific person, client, or investor. It provides general educational material and does not provide personalized recommendations.

## Conflicts and independence

Unless explicitly stated within an article, the author writes independently. If the author has a relevant conflict, position, or relationship connected to an article topic, it will be disclosed within that article.

## Use of sources

Where possible, content is based on public information and primary disclosures. However, errors can occur, and information can become outdated.

## Contact

Contact the author via LinkedIn:
<LINKEDIN_URL>
