---
title: "Privacy Policy"
description: "How decoded.finance collects and uses data."
pubDate: 2026-02-15
tags:
  - Legal
  - Privacy
---

## Summary

This policy explains how decoded.finance collects and uses personal data. If you do not agree with this policy, do not use the site.

## Data we collect

### Analytics data
We use Google Analytics to understand how visitors use the site. This may include:
- pages visited
- time on page
- device and browser information
- approximate location (city level)
- referral source

Google Analytics may use cookies and similar technologies depending on configuration and consent settings.

### Messages and contact
We do not provide email contact on the site. If you contact the author via LinkedIn, your data is processed under LinkedIn’s policies.

## How we use data

We use analytics data to:
- improve site performance and content quality
- understand what topics visitors find useful
- monitor site reliability and security

We do not sell personal data.

## Legal basis

Where applicable, we process data based on:
- legitimate interests in operating and improving the site
- consent for non-essential cookies, if enabled

## Data retention

Analytics retention depends on Google Analytics configuration. We aim to use reasonable retention periods and minimize data collection where possible.

## Third parties

We use:
- Google Analytics (Google)

Additional third-party services may be added later. This policy will be updated if that happens.

## Cookies

See the Cookies Policy for details on cookies and consent.

## Your rights

Depending on your jurisdiction, you may have rights relating to your personal data, including access, correction, deletion, or objection to processing.

## Contact

Contact the author via LinkedIn:
<LINKEDIN_URL>
