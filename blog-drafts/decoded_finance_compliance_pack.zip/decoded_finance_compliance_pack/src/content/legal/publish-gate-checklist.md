---
title: "Publish Gate Checklist"
description: "Internal checklist for publishing content safely and consistently."
pubDate: 2026-02-15
tags:
  - Internal
  - QA
  - Publishing
draft: true
---

## Content risk classification
- [ ] riskLevel is set: low, medium, or high
- [ ] If medium or high, include the Long Disclaimer block at the top

## Investment advice and solicitation
- [ ] No language that instructs the reader to buy, sell, hold, subscribe, avoid, or time the market
- [ ] No promises or implications of returns
- [ ] No personalized guidance or suitability language

## Sources and limitations
- [ ] Any key numbers have source notes or are clearly labeled as assumptions
- [ ] Any estimates have assumptions listed
- [ ] Risks and limitations are stated

## Conflicts and independence
- [ ] If relevant, disclose any relationship, role, or conflict connected to the topic
- [ ] If no conflict, do not claim “no conflict” unless you are sure. Use neutral language

## Tone and safety
- [ ] Avoid hype language that could be construed as promotion
- [ ] Avoid definitive predictions presented as certainty
- [ ] Avoid regulatory-sounding language that implies licensing or authorization

## Final checks
- [ ] Footer disclaimer will appear on the page
- [ ] The page links to Disclaimer and Terms in the footer
- [ ] Images are hosted locally in the repo and not linked to expiring sources
